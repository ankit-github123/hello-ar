import React from "react";
import AddUser from "./AddUser";
// import TableUser from "./TableUser";
import "./settings.css";
export default function SettingsMain() {

  return (
    <div>
      <AddUser />
      {/* <TableUser /> */}
    </div>
  );
}
