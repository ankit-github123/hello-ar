export const tabTitleList = [
    {
        title:"Products"
    },
    {
        title:"Demo Script"
    },
    {
        title:"Customers"
    },
    {
        title:"Sales Team"
    },
    {
        title:"Demos"
    },
    {
        title:"Settings"
    },
]

export const tabPanelList = [
    {
        title:"Products"
    },
    {
        title:"Demo Script"
    },
    {
        title:"Customers"
    },
    {
        title:"Sales Team"
    },
    {
        title:"Demos"
    },
    
]